import React from 'react'

const Bookdetails = () => {
  return (
    <div>
      
    </div>
  )
}

export default Bookdetails
